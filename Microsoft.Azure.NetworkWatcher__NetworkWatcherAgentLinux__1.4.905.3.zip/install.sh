#!/bin/sh

set -xv

disable()
{
    echo "Disabling Azure Network Watcher Agent"
    /etc/init.d/AzureNetworkWatcherAgent stop > /dev/null 2>&1

    forceKillOldAgent
}

uninstall()
{
    echo "Uninstall Azure Network Watcher Agent"
    disable
    ./NetworkWatcherAgent/NetworkWatcherAgent UnRegister /service /autoStart > /dev/null 2>&1
}

enable()
{
    echo "Enabling Azure Network Watcher Agent"
    ./NetworkWatcherAgent/NetworkWatcherAgent Register /service /autoStart
    /etc/init.d/AzureNetworkWatcherAgent start

    # after agent start the process controller forks child process that
    # initializing the environmet writing X.status file in
    # /var/lib/waagent/NWA folder. Unfortunately until environment is received
    # the status file could not be created since environment contains all the
    # informaton about destination folder, seq id etc. If X.status file is not
    # there waagent caused a failure that is shown in UI as deployment problem
    # even though agent is running successfully. In order to avoid the UI
    # failure the simple thing for now is to wait for a bit until fork is done,
    # later when waagent has better logic to handle a status it should be
    # removed.

    sleep 7s
}

forceKillOldAgent()
{
    echo "Force kill all NetworkWatcher Agent related processes"
    pkill -SIGKILL NetworkWatcher
}

install()
{
    forceKillOldAgent
    uninstall
    enable
}

GLIBC_MINVERSION="2.11"
GLIBC_MINVERSION_MAJOR=2
GLIBC_MINVERSION_MINOR=11

is_version_supported()
{
    curversion=$1

    if [ "$curversion" = "$GLIBC_MINVERSION" ]; then
        return 1
    fi

    local hasdot=0
    local delim=.
    case $curversion in
        *$delim*) hasdot=1;;
        *) hasdot=0;;
    esac

    if [ $hasdot -eq 1 ]; then
        firstval=`echo $curversion | cut -d "." -f 1`
        if [ $firstval -gt $GLIBC_MINVERSION_MAJOR ]; then
            return 1
        elif [ $firstval -lt $GLIBC_MINVERSION_MAJOR ]; then
            return 0
        else
            secondval=`echo $curversion | cut -d "." -f 2`
            if [ $secondval -ge $GLIBC_MINVERSION_MINOR ]; then
                return 1
            else
                return 0
            fi
        fi
    elif [ $curversion -gt $GLIBC_MINVERSION_MAJOR ]; then
        return 1
    else
        return 0
    fi
}

is_supported()
{
    echo "Checking if system is supported"
    output=$(ldd --version 2>/dev/null)
    if [ $? -eq 0 ]; then
        thisversion=$(echo "$output" | awk '/ldd/{print $NF}')
        is_version_supported $thisversion

        if [ $? -eq 1 ]; then
            return 1
        else
            return 0
        fi
    else
        return 0
    fi
}

is_supported
if [ $? -eq 0 ]; then
    echo "This system is not supported"
    exit 51
else
    echo "This system is supported"
fi

case "$1" in
    enable)
    enable
    ;;
    disable)
    disable
    ;;
    install)
    install
    ;;
    uninstall)
    uninstall
    ;;
    update)
    echo "Update Azure Network Watcher Agent"
    install
    ;;
    *)
    echo "Usage: $0 {install|uninstall|enable|disable|update}"
    exit 1
    ;;
esac
exit 0
